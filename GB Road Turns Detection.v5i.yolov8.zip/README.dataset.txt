# GB Road Turns Detection > 2023-10-14 6:00pm
https://universe.roboflow.com/nust-dsai-training-program/gb-road-turns-detection

Provided by a Roboflow user
License: CC BY 4.0

